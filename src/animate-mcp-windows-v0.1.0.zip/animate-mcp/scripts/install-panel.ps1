$ErrorActionPreference = 'Stop'
$dest = Join-Path $env:APPDATA 'Adobe\CEP\extensions\com.mike.animatemcp.panel'
if (Test-Path $dest) { throw "Panel already exists at $dest. Rename or remove that folder before reinstalling." }
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Copy-Item (Join-Path $PSScriptRoot '..\panel\*') $dest -Recurse
# Permit this unsigned development panel to load (per-user Adobe CEP debug setting).
foreach ($version in @('11','12')) {
 $key = "HKCU:\Software\Adobe\CSXS.$version"
 New-Item -Path $key -Force | Out-Null
 New-ItemProperty -Path $key -Name PlayerDebugMode -Value '1' -PropertyType String -Force | Out-Null
}
Write-Host "Installed at $dest. Restart Animate, then Window > Extensions > Animate MCP Bridge."
