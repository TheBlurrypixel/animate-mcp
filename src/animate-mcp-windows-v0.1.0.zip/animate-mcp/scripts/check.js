import {request} from '../src/config.js';import {script} from '../src/host.js';
try{console.log(await request('/status'));console.log(await request('/execute',{script:script('ping',{})}));console.log(await request('/execute',{script:script('info',{})}));}catch(e){console.error(e.message);process.exitCode=1;}
