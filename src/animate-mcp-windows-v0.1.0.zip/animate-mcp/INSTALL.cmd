@echo off
cd /d "%~dp0"
call npm ci
if errorlevel 1 goto done
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install-panel.ps1"
:done
pause
