@echo off
cd /d "%~dp0"
node src/bridge.js
pause
