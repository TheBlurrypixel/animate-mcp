(function(){
 var status=document.getElementById('status'),running=false,busy=false,timer;
 var nr=typeof require==='function'?require:window.cep_node.require;
 var fs=nr('fs'),path=nr('path'),http=nr('http'),crypto=nr('crypto');
 var client=crypto.randomBytes(16).toString('hex'),cfg;
 function call(route,body,cb){var raw=JSON.stringify(body);var r=http.request({hostname:'127.0.0.1',port:cfg.port,path:route,method:'POST',headers:{Authorization:'Bearer '+cfg.token,'Content-Type':'application/json','Content-Length':nr('buffer').Buffer.byteLength(raw)}},function(res){var s='';res.on('data',function(b){s+=b;});res.on('end',function(){try{var v=JSON.parse(s);if(res.statusCode!==200)throw Error(v.error);cb(null,v);}catch(e){cb(e);}});});r.on('error',function(e){cb(e);});r.setTimeout(5000,function(){r.destroy(Error('Bridge timeout'));});r.end(raw);}
 function later(){if(running)timer=setTimeout(poll,500);}
 function poll(){if(!running||busy)return;call('/poll',{client:client},function(e,v){if(e){status.textContent=e.message;later();return;}if(!v.id){status.textContent='Connected. Waiting for requests.';later();return;}busy=true;status.textContent='Running JSFL…';window.__adobe_cep__.evalScript(v.script,function(result){call('/result',{id:v.id,client:client,result:result},function(err){busy=false;status.textContent=err?'Result delivery failed. Do not repeat a change without inspecting Animate.':'Completed.';later();});});});}
 document.getElementById('connect').onclick=function(){if(running||busy)return;try{cfg=JSON.parse(fs.readFileSync(path.join(nr('process').env.APPDATA,'AnimateMCP','config.json'),'utf8'));running=true;poll();}catch(e){status.textContent='Start bridge first. '+e.message;}};
 document.getElementById('disconnect').onclick=function(){running=false;clearTimeout(timer);status.textContent=busy?'Disconnecting after current request.':'Disconnected.';};
})();
