// This function is serialized and executed by Animate's JSFL engine (ES3 syntax).
export function host(op,a){
 function enc(v){if(v===null||v===undefined)return 'null';if(typeof v==='string')return '"'+v.replace(/[\\"\x00-\x1f]/g,function(c){return '\\u'+('0000'+c.charCodeAt(0).toString(16)).slice(-4);})+'"';if(typeof v==='number')return isFinite(v)?String(v):'null';if(typeof v==='boolean')return String(v);var s=[],k;if(v instanceof Array){for(k=0;k<v.length;k++)s.push(enc(v[k]));return '['+s.join(',')+']';}for(k in v)if(v.hasOwnProperty(k))s.push(enc(k)+':'+enc(v[k]));return '{'+s.join(',')+'}';}
 try{
 if(op==='ping')return enc({ok:true,value:{version:fl.version}});
 var d=fl.getDocumentDOM();if(!d)throw Error('No open document');
 var t=d.getTimeline(),v,ls=t.layers,i,j,f;
 if(op==='info')v={name:d.name,path:d.pathURI||null,type:d.type,width:d.width,height:d.height,frameRate:d.frameRate,timeline:t.name,currentFrame:t.currentFrame+1,currentLayer:t.currentLayer+1};
 if(op==='selection'){v=[];for(i=0;i<d.selection.length;i++){var e=d.selection[i];v.push({name:e.name,elementType:e.elementType,instanceType:e.instanceType,libraryItem:e.libraryItem?e.libraryItem.name:null,x:e.x,y:e.y,width:e.width,height:e.height,matrix:e.matrix});}}
 if(op==='timeline'){v={name:t.name,layers:[]};for(i=0;i<ls.length;i++){var l=ls[i],frames=[];for(j=0;j<l.frames.length;j++){f=l.frames[j];if(f.startFrame===j)frames.push({frame:j+1,duration:f.duration,label:f.name,script:a.includeScripts?f.actionScript:undefined});}v.layers.push({layer:i+1,name:l.name,type:l.layerType,locked:l.locked,visible:l.visible,keyframes:frames});}}
 if(op==='read'||op==='write'){
 if(a.expectedDocument!==d.pathURI)throw Error('Document changed or is unsaved. Read document info and save it first.');
 if(a.expectedTimeline!==t.name)throw Error('Timeline changed. Inspect it again.');
 if(!ls[a.layer-1])throw Error('Layer does not exist');f=ls[a.layer-1].frames[a.frame-1];if(!f)throw Error('Frame does not exist');
 if(op==='write'){if(f.startFrame!==a.frame-1)throw Error('Target must be an existing keyframe');if(ls[a.layer-1].locked)throw Error('Layer is locked');if(f.actionScript!==a.expectedScript)throw Error('Script changed since reading; refusing overwrite');f.actionScript=a.script;}
 v={script:f.actionScript,keyframe:f.startFrame+1,document:d.pathURI,timeline:t.name};
 }
 if(op==='save'){if(!d.pathURI||a.expectedDocument!==d.pathURI)throw Error('Document changed or unsaved');fl.saveDocument(d);v={saved:true,path:d.pathURI};}
 if(op==='publish'){if(!d.pathURI||a.expectedDocument!==d.pathURI)throw Error('Document changed or unsaved');d.publish();v={published:true,path:d.pathURI};}
 return enc({ok:true,value:v});
 }catch(e){return enc({ok:false,error:String(e),line:e.lineNumber||null});}
}
export function script(op,args){return '('+host.toString()+')('+JSON.stringify(op)+','+JSON.stringify(args)+')';}
