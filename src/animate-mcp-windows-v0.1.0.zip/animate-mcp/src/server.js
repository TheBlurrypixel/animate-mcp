import {McpServer} from '@modelcontextprotocol/sdk/server/mcp.js';
import {StdioServerTransport} from '@modelcontextprotocol/sdk/server/stdio.js';
import {z} from 'zod';
import {request} from './config.js';
import {script} from './host.js';
const server=new McpServer({name:'adobe-animate',version:'0.1.0'});
const target={expectedDocument:z.string().min(1).describe('Exact path URI from get_document_info'),expectedTimeline:z.string().describe('Current timeline name from get_document_info'),layer:z.number().int().min(1),frame:z.number().int().min(1)};
function tool(name,description,schema,op,write=false){server.registerTool(name,{description,inputSchema:schema,annotations:{readOnlyHint:!write,destructiveHint:write,openWorldHint:false}},async a=>{try{const r=await request('/execute',{script:script(op,a)});const v=JSON.parse(r.result);if(!v.ok)throw Error(v.error);return {content:[{type:'text',text:JSON.stringify(v.value)}]};}catch(e){return {isError:true,content:[{type:'text',text:e.message}]};}});}
server.registerTool('bridge_status',{description:'Check whether Animate panel is connected',inputSchema:{},annotations:{readOnlyHint:true}},async()=>{try{return {content:[{type:'text',text:JSON.stringify(await request('/status'))}]};}catch(e){return {isError:true,content:[{type:'text',text:'Start START-BRIDGE.cmd first. '+e.message}]};}});
tool('get_animate_version','Check JSFL execution and Animate version',{},'ping');
tool('get_document_info','Inspect active document and current editing timeline',{},'info');
tool('get_selection','Inspect selected stage elements',{},'selection');
tool('get_timeline','Inspect current editing timeline. Frame and layer numbers are 1-based.',{includeScripts:z.boolean().default(false)},'timeline');
tool('get_frame_script','Read script at a frame on the current editing timeline',target,'read');
tool('set_frame_script','Replace script on an existing unlocked keyframe, checking previous text. Changes remain unsaved.',{...target,expectedScript:z.string(),script:z.string().max(150000)},'write',true);
tool('save_document','Save current document to its existing path',{expectedDocument:z.string().min(1)},'save',true);
tool('publish_document','Publish current document using active publish settings; may overwrite published files',{expectedDocument:z.string().min(1)},'publish',true);
if(process.env.ANIMATE_MCP_ALLOW_RAW==='1')server.registerTool('run_jsfl',{description:'Execute arbitrary JSFL. Full Animate scripting access; do not retry after timeout.',inputSchema:{code:z.string().max(150000)},annotations:{readOnlyHint:false,destructiveHint:true,openWorldHint:true}},async({code})=>{try{return {content:[{type:'text',text:String((await request('/execute',{script:code})).result)}]};}catch(e){return {isError:true,content:[{type:'text',text:e.message}]};}});
await server.connect(new StdioServerTransport());
