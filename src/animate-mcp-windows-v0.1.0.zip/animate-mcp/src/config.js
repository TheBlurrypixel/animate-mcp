import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
export const configPath=process.env.ANIMATE_MCP_CONFIG || path.join(process.env.APPDATA || os.homedir(),'AnimateMCP','config.json');
export function config(create=false){
 if(!fs.existsSync(configPath)&&create){fs.mkdirSync(path.dirname(configPath),{recursive:true});fs.writeFileSync(configPath,JSON.stringify({port:32124,token:crypto.randomBytes(32).toString('hex')},null,2),{mode:0o600});}
 const c=JSON.parse(fs.readFileSync(configPath,'utf8'));if(!Number.isInteger(c.port)||c.port<1024||c.port>65535||!c.token)throw Error('Invalid bridge configuration');return c;
}
export async function request(route,body){const c=config();const r=await fetch(`http://127.0.0.1:${c.port}${route}`,{method:body?'POST':'GET',headers:{authorization:'Bearer '+c.token,'content-type':'application/json'},body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(65000)});const v=await r.json();if(!r.ok)throw Error(v.error||'Bridge error');return v;}
