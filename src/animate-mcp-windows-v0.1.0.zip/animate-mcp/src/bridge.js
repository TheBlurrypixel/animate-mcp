import http from 'node:http';
import crypto from 'node:crypto';
import {config} from './config.js';
const c=config(true);let active=null,lastPoll=0,owner=null;
function send(r,status,v){r.writeHead(status,{'Content-Type':'application/json'});r.end(JSON.stringify(v));}
const server=http.createServer(async(req,res)=>{
 if(req.headers.host!==`127.0.0.1:${c.port}`||req.headers.origin||req.headers.authorization!=='Bearer '+c.token)return send(res,403,{error:'Forbidden'});
 try{
 let raw='';for await(const b of req){raw+=b;if(raw.length>1048576)return send(res,413,{error:'Request too large'});}const data=raw?JSON.parse(raw):{};
 if(req.method==='GET'&&req.url==='/status')return send(res,200,{connected:Date.now()-lastPoll<4000,busy:!!active});
 if(req.method==='POST'&&req.url==='/poll'){
 if(typeof data.client!=='string')throw Error('Missing panel identity');
 if(owner&&owner!==data.client&&Date.now()-lastPoll<4000)return send(res,409,{error:'Another Animate panel is connected'});
 owner=data.client;lastPoll=Date.now();
 if(active&&!active.sent){active.sent=true;return send(res,200,{id:active.id,script:active.script});}return send(res,200,{});
 }
 if(req.method==='POST'&&req.url==='/result'){
 if(!active||data.id!==active.id||data.client!==owner)return send(res,409,{error:'Expired or incorrect request'});
 clearTimeout(active.timer);send(active.res,200,{result:data.result});active=null;return send(res,200,{ok:true});
 }
 if(req.method==='POST'&&req.url==='/execute'){
 if(Date.now()-lastPoll>4000)return send(res,503,{error:'Open Window > Extensions > Animate MCP Bridge and click Connect.'});
 if(active)return send(res,409,{error:'Animate is busy. A timed-out request may still be executing; restart the bridge only after Animate finishes.'});
 if(typeof data.script!=='string'||data.script.length>250000)return send(res,400,{error:'Invalid script'});
 active={id:crypto.randomUUID(),script:data.script,res,sent:false};
 active.timer=setTimeout(()=>{if(!active)return;send(active.res,504,{error:active.sent?'Timed out after dispatch. Outcome unknown. Do not retry a mutation automatically.':'Request expired before dispatch.'});if(!active.sent)active=null;},55000);return;
 }
 send(res,404,{error:'Unknown route'});
 }catch(e){send(res,400,{error:e.message});}
});
server.on('error',e=>{console.error(e.message);process.exit(1)});
server.listen(c.port,'127.0.0.1',()=>console.error('Animate bridge listening on loopback port '+c.port));
