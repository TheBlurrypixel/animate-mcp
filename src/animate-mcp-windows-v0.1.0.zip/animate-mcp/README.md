# Adobe Animate MCP — Windows starter 0.1.0

A local MCP server and an unsigned CEP panel for Adobe Animate 2024 (24.x). The MCP process uses stdio; a separate authenticated loopback bridge delivers requests to the panel, which runs JSFL using Adobe's CEP evalScript API.

## First setup

1. Install Node.js 22 or newer from https://nodejs.org/ if needed.
2. Extract this entire ZIP into a permanent folder, for example `C:\Tools\animate-mcp`.
3. Close Animate. Double-click `INSTALL.cmd`. This runs `npm ci`, copies the panel to `%APPDATA%\Adobe\CEP\extensions\com.mike.animatemcp.panel`, and enables unsigned development extensions by setting the per-user Adobe `CSXS.11` and `CSXS.12` `PlayerDebugMode` values to `1`. It needs no administrator rights. The PowerShell execution-policy override applies only to that installer process.
4. Double-click `START-BRIDGE.cmd`; leave its console open.
5. Launch Animate 2024. Open a saved test FLA. Choose **Window > Extensions > Animate MCP Bridge**, then **Connect**. Keep the panel open.
6. Double-click `TEST-CONNECTION.cmd`. Expect `connected: true`, Animate's version, and document information. Send the output if it fails.

No Animate executable path is required. Use only one Animate bridge panel at a time. The bridge creates a private random token in `%APPDATA%\AnimateMCP\config.json`; do not share that file. Bridge port defaults to 32124. Do not forward this bridge port or put it in the ChatGPT Server URL field: it is an internal protocol, not an HTTP MCP endpoint.

## Connect local Codex

After the connection test passes, run in PowerShell (adjust your path):

```powershell
codex mcp add adobe-animate -- node "C:\Tools\animate-mcp\src\server.js"
```

The MCP client starts server.js. Keep START-BRIDGE.cmd running separately.

## Connect ChatGPT in a browser through Secure MCP Tunnel

This package provides the local stdio MCP command that a tunnel client can launch. It does not create your OpenAI tunnel or provision account permissions.

Follow the current official guide:
https://developers.openai.com/api/docs/guides/secure-mcp-tunnels

Create a tunnel in Platform tunnel settings, obtain its `tunnel_id`, and install/configure the official tunnel client on this PC. Its MCP command must launch `node` with the absolute path to `src/server.js` (quote paths with spaces). The guide requires a runtime API key and tunnel permissions. Keep that key locally; do not paste it in chat. Follow the guide's current Windows installation and authentication instructions.

Keep both the local bridge and tunnel client running, and keep the Animate panel connected. Return to ChatGPT's **Create custom MCP server** form, choose **Tunnel**, enter your actual tunnel ID, and configure authentication to match the stdio tunnel setup. This local server implements no OAuth service. Do not fill in invented OAuth credentials. Account/tunnel setup remains a separate step after the local test passes.

## Available tools

- bridge_status
- get_animate_version
- get_document_info
- get_selection
- get_timeline (optional scripts)
- get_frame_script
- set_frame_script
- save_document
- publish_document

Layer/frame numbers are **1-based**. Timeline operations use the current editing timeline, including a nested symbol if you are editing it. Do not navigate or edit while a request runs. A write requires the exact saved document URI, timeline name and old script text. Timeline names are not globally unique; do not switch between equally named timelines between reading and writing. set_frame_script replaces an existing unlocked keyframe's script; it does not create layers/keyframes or save automatically. Publishing uses the active profile and can overwrite outputs. JSFL access to global-script settings is not included in this version.

Raw JSFL is disabled by default. To expose run_jsfl, set `ANIMATE_MCP_ALLOW_RAW=1` in the MCP process environment. This gives full JSFL access, including file operations supported by Animate. Normal frame-script writes can themselves introduce runtime behavior when the project is published and run.

## Timeouts and disconnects

Only one request runs at a time. A request that times out before dispatch is removed. If Animate already received it, the bridge stays busy until its result arrives. Never automatically retry a timed-out mutation: inspect the document first. Disconnect prevents future polling; it cannot interrupt JSFL already executing. Restart the bridge only after confirming Animate finished. Dialogs and long publish operations can exceed the 55-second timeout.

## Troubleshooting / removal

- Panel absent: confirm Animate is version 24.x, restart it after install, and check the installed manifest path. This panel uses CEP Node integration.
- Port in use: close an old bridge console. To change ports, stop bridge and panel, edit the port in config.json, then restart/reconnect both.
- Reinstall: remove or rename the existing `com.mike.animatemcp.panel` extension folder first; the installer intentionally refuses to overwrite it.
- Remove: close Animate/bridge, delete that extension folder and this project folder. Delete `%APPDATA%\AnimateMCP` if no longer needed. If you enabled Adobe PlayerDebugMode solely for this panel, restore its prior setting or remove the values; other development panels may depend on them.

## Validation and limits

Run `npm test`. Tests cover MCP initialization/tool discovery and JSFL serialization/write guards using a mock document. Actual Adobe Animate/CEP execution, Windows installation, UI responsiveness, and browser tunnel connection require a Windows machine with Animate; they have not been tested in this build environment. No automatic backup or grouped undo is promised; start with a copy of an FLA.

## References

Adobe CEP / JSFL integration:
https://helpx.adobe.com/animate/desktop/workspace-and-workflow/creating-html-extensions.html

MCP SDK v1:
https://ts.sdk.modelcontextprotocol.io/server
